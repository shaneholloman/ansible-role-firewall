## 1.0.0 (2023-09-29)

* Added support for Ubuntu 22.04